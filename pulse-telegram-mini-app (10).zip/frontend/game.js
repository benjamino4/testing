/* ========================================================================
   PULSE — Space Explorer (v2)
   Real launch from Earth → free flight through deep space → dodge falling
   asteroids → discover real-scaled planets → land + snapshot + share.
   Monochrome. Built for Telegram mini-app webviews (touch-first, DPR-safe).
   ===================================================================== */
(() => {
  'use strict';
  const tg = window.Telegram && window.Telegram.WebApp ? window.Telegram.WebApp : null;
  const $ = id => document.getElementById(id);
  const PULSE = () => (window.PULSE || {});
  const TAU = Math.PI * 2;
  function api(path, extra) {
    const initData = PULSE().initData || '';
    return fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Init-Data': initData }, body: JSON.stringify({ initData, ...(extra || {}) }) }).then(r => r.json()).catch(() => null);
  }
  function haptic(k) { try { if (!tg || !tg.HapticFeedback) return; if (k === 'hit') tg.HapticFeedback.impactOccurred('heavy'); else if (k === 'ok') tg.HapticFeedback.notificationOccurred('success'); else if (k === 'warn') tg.HapticFeedback.notificationOccurred('warning'); else tg.HapticFeedback.impactOccurred('light'); } catch (_) {} }

  // ---- real astronomy (planets keep real distance ratios) ----------------
  const AU_KM = 149597870;
  const PX_PER_AU = 2600;
  const EARTH_AU = 1.0;
  const PLANETS = [
    { id: 'mars', name: 'Mars', au: 1.52, dia: 6779, r: 30, x: -170, rings: false, shade: 0.60 },
    { id: 'jupiter', name: 'Jupiter', au: 5.20, dia: 139820, r: 96, x: 220, rings: false, shade: 0.46, bands: true },
    { id: 'saturn', name: 'Saturn', au: 9.58, dia: 116460, r: 82, x: -250, rings: true, shade: 0.70 },
    { id: 'uranus', name: 'Uranus', au: 19.20, dia: 50724, r: 56, x: 250, rings: true, shade: 0.82 },
    { id: 'neptune', name: 'Neptune', au: 30.05, dia: 49244, r: 54, x: -190, rings: false, shade: 0.64 },
  ];
  PLANETS.forEach(p => { p.auFromEarth = p.au - EARTH_AU; });
  const fmt = n => Math.round(n).toLocaleString('en-US');

  // ---- runtime ------------------------------------------------------------
  const cv = $('gameCanvas'), ctx = cv ? cv.getContext('2d') : null;
  let W = 0, H = 0, dpr = 1, running = false, raf = 0, last = 0, t = 0;
  let phase = 'launch', launchT = 0, landT = 0, deadT = 0, shakeT = 0, hintT = 0;
  let boost = 0, boostReady = 1, shields = 3, invuln = 0, score = 0;
  let stars = [], starsFar = [], exhaust = [], asteroids = [], shooters = [], debris = [];
  const rocket = { x: 0, y: 0, vx: 0, vy: 0, ang: -Math.PI / 2 };
  const pointer = { on: false, x: 0, y: 0 };
  let reached = new Set(), current = null, astTimer = 0, shootTimer = 0;
  const ROCK_SX = () => W / 2;
  const ROCK_SY = () => H * 0.60;
  const PPAU = () => PX_PER_AU * dpr;
  const EARTH_R = () => 340 * dpr;
  const EARTH_CY = () => -(EARTH_R() + 6 * dpr);   // world y of Earth centre
  // scenic companions (device-px world coords)
  const SUN = { x: () => -0.62 * W - 220 * dpr, y: () => -0.10 * PPAU(), r: () => 300 * dpr };
  const MOON = { x: () => 0.42 * W + 260 * dpr, y: () => 0.34 * PPAU(), r: () => 78 * dpr };

  function resize() {
    if (!cv) return;
    dpr = Math.min(window.devicePixelRatio || 1, 2.5);
    W = cv.width = Math.round(innerWidth * dpr);
    H = cv.height = Math.round(innerHeight * dpr);
    cv.style.width = innerWidth + 'px'; cv.style.height = innerHeight + 'px';
    buildStars();
  }
  function buildStars() {
    stars = []; starsFar = [];
    const n = Math.round(W * H / (7000));
    for (let i = 0; i < n; i++) stars.push({ x: Math.random() * W, y: Math.random() * H, z: 0.5 + Math.random() * 0.6, ph: Math.random() * TAU, r: (0.4 + Math.random() * 1.6) * dpr });
    const nf = Math.round(W * H / (22000));
    for (let i = 0; i < nf; i++) starsFar.push({ x: Math.random() * W, y: Math.random() * H, z: 0.12 + Math.random() * 0.25, ph: Math.random() * TAU, r: (0.3 + Math.random()) * dpr });
  }
  function sx(wx) { return ROCK_SX() + (wx - rocket.x); }
  function sy(wy) { return ROCK_SY() - (wy - rocket.y); }
  function rand(a, b) { return a + Math.random() * (b - a); }
  // ---- rocket shape (points up: nose at -y) -------------------------------
  function drawRocketShape(g, s, thrust) {
    // exhaust flame
    if (thrust > 0.02) {
      const fl = (14 + thrust * 26 + Math.random() * 8) * s;
      g.beginPath();
      g.moveTo(-4.4 * s, 12 * s); g.quadraticCurveTo(-2 * s, 12 * s + fl * 0.5, 0, 12 * s + fl);
      g.quadraticCurveTo(2 * s, 12 * s + fl * 0.5, 4.4 * s, 12 * s);
      g.closePath();
      g.fillStyle = 'rgba(255,255,255,' + (0.55 + 0.4 * Math.random()) + ')'; g.fill();
      g.beginPath(); g.moveTo(-2.4 * s, 12 * s); g.lineTo(0, 12 * s + fl * 0.6); g.lineTo(2.4 * s, 12 * s); g.closePath();
      g.fillStyle = '#000'; g.fill();
    }
    // fins
    g.fillStyle = '#fff';
    g.beginPath(); g.moveTo(-4.6 * s, 4 * s); g.lineTo(-10 * s, 14 * s); g.lineTo(-4.6 * s, 12 * s); g.closePath(); g.fill();
    g.beginPath(); g.moveTo(4.6 * s, 4 * s); g.lineTo(10 * s, 14 * s); g.lineTo(4.6 * s, 12 * s); g.closePath(); g.fill();
    // body (capsule)
    g.beginPath();
    g.moveTo(-4.6 * s, 12 * s);
    g.lineTo(-4.6 * s, -6 * s);
    g.quadraticCurveTo(-4.6 * s, -15 * s, 0, -22 * s);      // nose cone
    g.quadraticCurveTo(4.6 * s, -15 * s, 4.6 * s, -6 * s);
    g.lineTo(4.6 * s, 12 * s);
    g.closePath();
    g.fillStyle = '#fff'; g.fill();
    // body shading seam
    g.beginPath(); g.moveTo(1.4 * s, -12 * s); g.lineTo(1.4 * s, 11 * s);
    g.lineWidth = 1.2 * s; g.strokeStyle = 'rgba(0,0,0,0.18)'; g.stroke();
    // window
    g.beginPath(); g.arc(0, -5 * s, 3 * s, 0, TAU); g.fillStyle = '#000'; g.fill();
    g.beginPath(); g.arc(-0.8 * s, -5.8 * s, 1.1 * s, 0, TAU); g.fillStyle = 'rgba(255,255,255,0.7)'; g.fill();
    // fin base line
    g.beginPath(); g.moveTo(-4.6 * s, 12 * s); g.lineTo(4.6 * s, 12 * s); g.lineWidth = 1 * s; g.strokeStyle = 'rgba(0,0,0,0.25)'; g.stroke();
  }

  // ---- input --------------------------------------------------------------
  function bindInput() {
    const move = e => { const p = e.touches ? e.touches[0] : e; if (!p) return; pointer.x = p.clientX * dpr; pointer.y = p.clientY * dpr; };
    const down = e => { pointer.on = true; move(e); if (e.cancelable) e.preventDefault(); };
    const up = () => { pointer.on = false; };
    cv.addEventListener('pointerdown', down);
    cv.addEventListener('pointermove', e => { if (pointer.on) move(e); });
    addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    cv.addEventListener('touchstart', down, { passive: false });
    cv.addEventListener('touchmove', e => { if (pointer.on) { move(e); if (e.cancelable) e.preventDefault(); } }, { passive: false });
    addEventListener('touchend', up);
  }
  function fireBoost() {
    if (boostReady < 1 || phase !== 'fly') return;
    boost = 1.7; boostReady = 0; haptic('hit'); shakeT = 0.35;
  }

  // ---- launch sequence ----------------------------------------------------
  function updateLaunch(dt) {
    launchT += dt;
    shakeT = Math.max(shakeT, 0.06);
    if (launchT < 0.7) {                     // ignition on the pad
      spawnExhaust(3, 1.4);
    } else {                                  // lift-off
      const a = Math.min(1, (launchT - 0.7) / 2.0);
      rocket.vy += (520 + a * 1400) * dpr * dt;
      rocket.y += rocket.vy * dt;
      rocket.ang = -Math.PI / 2;
      spawnExhaust(4, 1.6);
    }
    // hand off to free flight once well clear of the atmosphere
    if (rocket.y > EARTH_R() * 0.9 && launchT > 1.6) { phase = 'fly'; hintT = 3.2; shakeT = 0.2; rocket.vy = Math.min(rocket.vy, 720 * dpr); }
    stepParticles(dt);
    updateHud();
  }

  // ---- free-flight simulation --------------------------------------------
  function update(dt) {
    if (phase === 'launch') return updateLaunch(dt);
    if (phase === 'landing') { landT += dt; stepParticles(dt); return; }
    if (phase === 'dead') { deadT += dt; stepParticles(dt); if (deadT > 1.9) respawn(); return; }
    if (phase !== 'fly') { stepParticles(dt); return; }
    if (hintT > 0) hintT -= dt;
    boost = Math.max(0, boost - dt * 0.85);
    boostReady = Math.min(1, boostReady + dt / 6);
    invuln = Math.max(0, invuln - dt);
    const maxV = (640 + boost * 3400) * dpr;
    if (pointer.on) {
      const dx = pointer.x - ROCK_SX(), dy = pointer.y - ROCK_SY();
      const len = Math.hypot(dx, dy) || 1;
      const acc = (980 + boost * 2800) * dpr;
      rocket.vx += (dx / len) * acc * dt;
      rocket.vy += (-dy / len) * acc * dt;
      rocket.ang = Math.atan2(-dy, dx);
      spawnExhaust(2, 1);
    } else {
      rocket.vx *= (1 - Math.min(1, dt * 0.5));
      rocket.vy *= (1 - Math.min(1, dt * 0.5));
    }
    const sp = Math.hypot(rocket.vx, rocket.vy);
    if (sp > maxV) { rocket.vx *= maxV / sp; rocket.vy *= maxV / sp; }
    rocket.x += rocket.vx * dt; rocket.y += rocket.vy * dt;
    if (rocket.y < -EARTH_R() * 0.4) { rocket.y = -EARTH_R() * 0.4; rocket.vy = Math.max(0, rocket.vy); }
    score = Math.max(score, rocket.y);
    spawnAsteroids(dt); spawnShooters(dt);
    stepAsteroids(dt); stepParticles(dt);
    checkDiscovery();
    updateHud();
  }

  // ---- spawners & particles ----------------------------------------------
  function spawnExhaust(count, scale) {
    if (exhaust.length > 140) return;
    const bx = ROCK_SX() - Math.cos(rocket.ang) * 18 * dpr, by = ROCK_SY() - Math.sin(rocket.ang) * 18 * dpr;
    for (let i = 0; i < count; i++) exhaust.push({ x: bx, y: by, vx: (-Math.cos(rocket.ang) * 70 + rand(-50, 50)) * dpr, vy: (-Math.sin(rocket.ang) * 70 + rand(-50, 50)) * dpr, life: rand(0.4, 0.9), r: rand(1, 3) * (scale || 1) * dpr });
  }
  function stepParticles(dt) {
    for (let i = exhaust.length - 1; i >= 0; i--) { const e = exhaust[i]; e.x += e.vx * dt; e.y += e.vy * dt; e.life -= dt * 1.7; if (e.life <= 0) exhaust.splice(i, 1); }
    for (let i = shooters.length - 1; i >= 0; i--) { const s = shooters[i]; s.x += s.vx * dt; s.y += s.vy * dt; s.life -= dt; if (s.life <= 0) shooters.splice(i, 1); }
    for (let i = debris.length - 1; i >= 0; i--) { const d = debris[i]; d.x += d.vx * dt; d.y += d.vy * dt; d.life -= dt * 1.2; if (d.life <= 0) debris.splice(i, 1); }
  }
  function spawnShooters(dt) {
    shootTimer -= dt; if (shootTimer > 0) return; shootTimer = rand(1.6, 4.2);
    const edge = Math.random() < 0.5;
    shooters.push({ x: edge ? rand(0, W) : -20 * dpr, y: edge ? -20 * dpr : rand(0, H * 0.5), vx: rand(220, 420) * dpr, vy: rand(160, 320) * dpr, life: rand(0.5, 0.9), len: rand(60, 150) * dpr });
  }
  function spawnAsteroids(dt) {
    astTimer -= dt; if (astTimer > 0) return;
    const alt = rocket.y / PPAU();                 // AU travelled
    const density = Math.min(1, 0.25 + alt * 0.09); // more the deeper you go
    astTimer = rand(0.5, 1.4) / density;
    // spawn ahead of travel direction, a screen-height away, falling toward rocket
    const spread = W * 0.9;
    const wx = rocket.x + rand(-spread, spread);
    const wy = rocket.y + H * rand(0.75, 1.25);    // above (further out)
    const rad = rand(10, 30) * dpr;
    const verts = [];
    const vn = 7 + (Math.random() * 4 | 0);
    for (let i = 0; i < vn; i++) verts.push(rad * rand(0.66, 1.15));
    asteroids.push({ x: wx, y: wy, vx: rand(-60, 60) * dpr, vy: -rand(120, 260) * dpr, r: rad, rot: rand(0, TAU), vr: rand(-1.4, 1.4), verts, vn });
  }
  function stepAsteroids(dt) {
    const cr = 13 * dpr;
    for (let i = asteroids.length - 1; i >= 0; i--) {
      const a = asteroids[i];
      a.x += a.vx * dt; a.y += a.vy * dt; a.rot += a.vr * dt;
      // cull when far below / far off
      if (a.y < rocket.y - H * 1.4 || Math.abs(a.x - rocket.x) > W * 1.6) { asteroids.splice(i, 1); continue; }
      if (invuln <= 0 && phase === 'fly') {
        const d = Math.hypot(a.x - rocket.x, a.y - rocket.y);
        if (d < a.r + cr) { asteroids.splice(i, 1); hitRocket(a); }
      }
    }
  }
  function hitRocket(a) {
    shields -= 1; invuln = 1.6; shakeT = 0.5; haptic('warn');
    rocket.vx += (rocket.x - a.x) * 2.2; rocket.vy += (rocket.y - a.y) * 2.2;
    burst(rocket.x, rocket.y, 10, 220);
    if (shields <= 0) destroyRocket();
  }
  function burst(x, y, n, spd) {
    for (let i = 0; i < n; i++) { const ang = rand(0, TAU); debris.push({ x, y, vx: Math.cos(ang) * rand(spd * 0.4, spd) * dpr, vy: Math.sin(ang) * rand(spd * 0.4, spd) * dpr, life: rand(0.5, 1.1), r: rand(1.2, 3.4) * dpr }); }
  }
  function destroyRocket() {
    phase = 'dead'; deadT = 0; shakeT = 0.8; haptic('warn');
    burst(rocket.x, rocket.y, 46, 420); rocket.vx = rocket.vy = 0;
  }
  function respawn() {
    phase = 'fly'; shields = 3; invuln = 2.2; boost = 0; hintT = 2.4;
    asteroids = []; rocket.vx = rocket.vy = 0; rocket.ang = -Math.PI / 2;
  }
  // ---- discovery ----------------------------------------------------------
  function checkDiscovery() {
    for (const p of PLANETS) {
      if (reached.has(p.id)) continue;
      const wx = p.x * dpr, wy = p.auFromEarth * PPAU();
      const d = Math.hypot(wx - rocket.x, wy - rocket.y);
      if (d < (p.r * dpr + 92 * dpr)) { onDiscover(p); break; }
    }
  }

  // ---- render -------------------------------------------------------------
  function render() {
    // deep-space backdrop with a faint central glow
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
    const bg = ctx.createRadialGradient(W * 0.5, H * 0.42, 0, W * 0.5, H * 0.42, Math.max(W, H) * 0.7);
    bg.addColorStop(0, 'rgba(255,255,255,0.05)'); bg.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
    drawStarLayer(starsFar, 0.015); drawStarLayer(stars, 0.03);
    drawShooters();
    drawSun(); drawMoon();
    drawBody({ name: 'Earth', r: 340, shade: 0.9, earth: true }, 0, EARTH_CY() / PPAU() * PPAU(), true);
    for (const p of PLANETS) drawBody(p, p.x * dpr, p.auFromEarth * PPAU(), false);
    drawAsteroids();
    // particles
    for (const e of exhaust) { ctx.beginPath(); ctx.fillStyle = 'rgba(255,255,255,' + (0.5 * e.life) + ')'; ctx.arc(e.x, e.y, e.r, 0, TAU); ctx.fill(); }
    for (const d of debris) { ctx.beginPath(); ctx.fillStyle = 'rgba(255,255,255,' + (0.85 * d.life) + ')'; ctx.arc(d.x, d.y, d.r, 0, TAU); ctx.fill(); }
    if (boost > 0.05) {
      ctx.strokeStyle = 'rgba(255,255,255,' + (0.22 * boost) + ')'; ctx.lineWidth = dpr;
      for (let i = 0; i < 22; i++) { const rx = Math.random() * W, ry = Math.random() * H; ctx.beginPath(); ctx.moveTo(rx, ry); ctx.lineTo(rx, ry + 70 * dpr * boost); ctx.stroke(); }
    }
    if (phase !== 'dead') drawRocket();
  }
  function drawStarLayer(arr, par) {
    for (const s of arr) {
      const ox = (-rocket.x * par * s.z) % W, oy = (rocket.y * par * s.z) % H;
      let x = s.x + ox; if (x < 0) x += W; if (x > W) x -= W;
      let y = s.y + oy; if (y < 0) y += H; if (y > H) y -= H;
      const tw = 0.55 + 0.45 * Math.sin(t * 1.6 + s.ph);
      ctx.beginPath(); ctx.fillStyle = 'rgba(255,255,255,' + (0.85 * tw * s.z) + ')'; ctx.arc(x, y, s.r, 0, TAU); ctx.fill();
    }
  }
  function drawShooters() {
    for (const s of shooters) {
      const a = Math.min(1, s.life * 1.6);
      const nx = s.vx / Math.hypot(s.vx, s.vy), ny = s.vy / Math.hypot(s.vx, s.vy);
      const g = ctx.createLinearGradient(s.x, s.y, s.x - nx * s.len, s.y - ny * s.len);
      g.addColorStop(0, 'rgba(255,255,255,' + (0.9 * a) + ')'); g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.strokeStyle = g; ctx.lineWidth = 1.6 * dpr; ctx.beginPath(); ctx.moveTo(s.x, s.y); ctx.lineTo(s.x - nx * s.len, s.y - ny * s.len); ctx.stroke();
    }
  }
  function drawSun() {
    const x = sx(SUN.x()), y = sy(SUN.y()), r = SUN.r();
    if (x < -r * 1.5 || x > W + r * 1.5 || y < -r * 1.5 || y > H + r * 1.5) return;
    const g = ctx.createRadialGradient(x, y, 0, x, y, r * 1.7);
    g.addColorStop(0, 'rgba(255,255,255,0.95)'); g.addColorStop(0.32, 'rgba(255,255,255,0.5)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * 1.7, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.fillStyle = '#fff'; ctx.arc(x, y, r * 0.5, 0, TAU); ctx.fill();
  }
  function drawMoon() {
    const x = sx(MOON.x()), y = sy(MOON.y()), r = MOON.r();
    if (x < -r * 2 || x > W + r * 2 || y < -r * 2 || y > H + r * 2) return;
    const g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.35, r * 0.1, x, y, r);
    g.addColorStop(0, 'rgba(255,255,255,0.85)'); g.addColorStop(1, 'rgba(255,255,255,0.18)');
    ctx.beginPath(); ctx.fillStyle = g; ctx.arc(x, y, r, 0, TAU); ctx.fill();
    ctx.save(); ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.clip();
    ctx.fillStyle = 'rgba(0,0,0,0.16)';
    [[0.2, -0.3, 0.22], [-0.35, 0.1, 0.3], [0.1, 0.4, 0.18], [0.45, 0.25, 0.14]].forEach(c => { ctx.beginPath(); ctx.arc(x + c[0] * r, y + c[1] * r, c[2] * r, 0, TAU); ctx.fill(); });
    ctx.restore();
    ctx.beginPath(); ctx.lineWidth = 1.2 * dpr; ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.arc(x, y, r, 0, TAU); ctx.stroke();
    label('MOON', x, y + r + 18 * dpr, 0.55);
  }
  function drawBody(p, wx, wy, big) {
    const r = (p.earth ? EARTH_R() : p.r * dpr);
    const cy = p.earth ? EARTH_CY() : wy;
    const x = sx(wx), y = sy(cy);
    if (x < -r * 2.2 || x > W + r * 2.2 || y < -r * 2.2 || y > H + r * 2.2) return;
    if (p.rings) { ctx.save(); ctx.translate(x, y); ctx.rotate(-0.5); ctx.scale(1, 0.32); ctx.beginPath(); ctx.arc(0, 0, r * 1.95, 0, TAU); ctx.lineWidth = 7 * dpr; ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.stroke(); ctx.beginPath(); ctx.arc(0, 0, r * 1.55, 0, TAU); ctx.lineWidth = 3 * dpr; ctx.strokeStyle = 'rgba(255,255,255,0.3)'; ctx.stroke(); ctx.restore(); }
    const sh = p.shade || 0.6;
    const g = ctx.createRadialGradient(x - r * 0.34, y - r * 0.34, r * 0.1, x, y, r);
    g.addColorStop(0, 'rgba(255,255,255,' + (0.92 * sh + 0.08) + ')');
    g.addColorStop(1, 'rgba(255,255,255,' + (0.1 * sh) + ')');
    ctx.beginPath(); ctx.fillStyle = g; ctx.arc(x, y, r, 0, TAU); ctx.fill();
    if (p.bands || p.earth) {
      ctx.save(); ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.clip();
      ctx.strokeStyle = 'rgba(0,0,0,0.10)'; ctx.lineWidth = r * 0.14;
      for (let i = -2; i <= 3; i++) { ctx.beginPath(); ctx.moveTo(x - r, y + i * r * 0.34); ctx.bezierCurveTo(x - r * 0.3, y + i * r * 0.34 + r * 0.08, x + r * 0.3, y + i * r * 0.34 - r * 0.08, x + r, y + i * r * 0.34); ctx.stroke(); }
      ctx.restore();
    }
    ctx.beginPath(); ctx.lineWidth = 1.5 * dpr; ctx.strokeStyle = 'rgba(255,255,255,0.8)'; ctx.arc(x, y, r, 0, TAU); ctx.stroke();
    if (!p.earth) label(p.name.toUpperCase(), x, y + r + 20 * dpr, 0.82);
    else label('EARTH', x, sy(0) - 26 * dpr, 0.7);
  }
  function drawAsteroids() {
    for (const a of asteroids) {
      const x = sx(a.x), y = sy(a.y);
      if (x < -a.r * 2 || x > W + a.r * 2 || y < -a.r * 2 || y > H + a.r * 2) continue;
      ctx.save(); ctx.translate(x, y); ctx.rotate(a.rot);
      ctx.beginPath();
      for (let i = 0; i < a.vn; i++) { const ang = i / a.vn * TAU; const rr = a.verts[i]; const px = Math.cos(ang) * rr, py = Math.sin(ang) * rr; i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }
      ctx.closePath();
      ctx.fillStyle = 'rgba(255,255,255,0.16)'; ctx.fill();
      ctx.lineWidth = 1.6 * dpr; ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.stroke();
      ctx.beginPath(); ctx.arc(-a.r * 0.2, -a.r * 0.15, a.r * 0.2, 0, TAU); ctx.arc(a.r * 0.25, a.r * 0.1, a.r * 0.13, 0, TAU); ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.fill();
      ctx.restore();
    }
  }
  function drawRocket() {
    const x = ROCK_SX(), y = ROCK_SY();
    if (invuln > 0 && phase === 'fly' && (Math.sin(t * 30) < 0)) return; // blink when hit
    let thrust = pointer.on ? 0.7 : 0.06;
    if (phase === 'launch') thrust = launchT < 0.7 ? (0.4 + Math.random() * 0.4) : 1.2;
    ctx.save(); ctx.translate(x, y); ctx.rotate(rocket.ang + Math.PI / 2);
    drawRocketShape(ctx, 1.4 * dpr, thrust);
    ctx.restore();
    if (invuln > 0 && phase === 'fly') { ctx.beginPath(); ctx.lineWidth = 1.4 * dpr; ctx.strokeStyle = 'rgba(255,255,255,' + (0.3 + 0.25 * Math.sin(t * 20)) + ')'; ctx.arc(x, y, 26 * dpr, 0, TAU); ctx.stroke(); }
  }
  function label(txt, x, y, a) {
    ctx.fillStyle = 'rgba(255,255,255,' + (a || 0.8) + ')';
    ctx.font = (12 * dpr) + 'px ui-monospace,Menlo,monospace'; ctx.textAlign = 'center';
    ctx.fillText(txt, x, y);
  }
  // ---- HUD ----------------------------------------------------------------
  function updateHud() {
    const kmY = rocket.y / PPAU() * AU_KM, kmX = rocket.x / PPAU() * AU_KM;
    setTxt('gY', 'Y ' + fmt(kmY) + ' km'); setTxt('gX', 'X ' + fmt(kmX) + ' km');
    const sp = Math.hypot(rocket.vx, rocket.vy) / PPAU() * AU_KM / 1000;
    setTxt('gSpeed', fmt(sp) + ' km/s' + (boost > 0.05 ? '  \u26a1' : ''));
    const sh = $('gShields'); if (sh) { const n = Math.max(0, shields); sh.textContent = '\u25c6'.repeat(n) + '\u25c7'.repeat(3 - n); }
    let best = null, bd = Infinity;
    for (const p of PLANETS) { if (reached.has(p.id)) continue; const wx = p.x * dpr, wy = p.auFromEarth * PPAU(); const d = Math.hypot(wx - rocket.x, wy - rocket.y); if (d < bd) { bd = d; best = { wx, wy }; } }
    const arrow = $('gArrow'), dist = $('gDist');
    if (arrow && dist) {
      if (best) { const ang = Math.atan2(-(best.wy - rocket.y), best.wx - rocket.x); arrow.style.transform = 'rotate(' + (-ang + Math.PI / 2) + 'rad)'; arrow.style.opacity = '1'; dist.textContent = fmt(bd / PPAU() * AU_KM) + ' km'; }
      else { arrow.style.opacity = '.2'; dist.textContent = 'all found'; }
    }
    const bb = $('gBoost'); if (bb) bb.classList.toggle('ready', boostReady >= 1 && phase === 'fly');
    const msg = $('gMsg');
    if (msg) {
      if (phase === 'dead') { msg.hidden = false; msg.className = 'g-msg warn'; msg.textContent = 'SIGNAL LOST \u2014 rebooting\u2026'; }
      else if (phase === 'launch') { msg.hidden = false; msg.className = 'g-msg'; msg.textContent = launchT < 0.7 ? 'IGNITION' : 'LIFT-OFF'; }
      else if (hintT > 0 && phase === 'fly') { msg.hidden = false; msg.className = 'g-msg'; msg.textContent = 'drag to steer \u00b7 dodge asteroids'; }
      else msg.hidden = true;
    }
  }
  function setTxt(id, v) { const el = $(id); if (el) el.textContent = v; }

  function loop(now) {
    if (!running) return;
    const dt = last ? Math.min(0.05, (now - last) / 1000) : 0.016; last = now; t += dt;
    update(dt);
    ctx.save();
    if (shakeT > 0) { shakeT -= dt; const m = (phase === 'launch' ? 5 : 10) * dpr * Math.min(1, shakeT * 2); ctx.translate(rand(-m, m), rand(-m, m)); }
    render();
    ctx.restore();
    raf = requestAnimationFrame(loop);
  }

  // ---- discovery / land / snapshot ---------------------------------------
  function onDiscover(p) {
    reached.add(p.id); current = p; phase = 'discover'; shakeT = 0.4; haptic('ok');
    rocket.vx *= 0.15; rocket.vy *= 0.15;
    setTxt('gpName', p.name);
    $('gpStats').innerHTML =
      '<div><span>DISTANCE FROM SUN</span><b>' + p.au.toFixed(2) + ' AU</b></div>' +
      '<div><span>DIAMETER</span><b>' + fmt(p.dia) + ' km</b></div>' +
      '<div><span>FROM EARTH</span><b>' + fmt(Math.abs(p.auFromEarth) * AU_KM) + ' km</b></div>';
    show('gDiscover', true);
    api('/api/game/discover', { planet_id: p.id }).then(() => { const r = PULSE().refresh; r && r(); });
  }
  function land() { show('gDiscover', false); phase = 'landing'; landT = 0; setTimeout(makeSnapshot, 1100); }
  function makeSnapshot() {
    const c = document.createElement('canvas'); c.width = 1080; c.height = 1350;
    const g = c.getContext('2d');
    g.fillStyle = '#000'; g.fillRect(0, 0, 1080, 1350);
    for (let i = 0; i < 300; i++) { g.fillStyle = 'rgba(255,255,255,' + (0.2 + Math.random() * 0.7) + ')'; g.beginPath(); g.arc(Math.random() * 1080, Math.random() * 1350, Math.random() * 1.9, 0, TAU); g.fill(); }
    const p = current, cx = 540, cy = 600, R = 300;
    if (p.rings) { g.save(); g.translate(cx, cy); g.rotate(-0.5); g.scale(1, 0.32); g.beginPath(); g.arc(0, 0, R * 1.9, 0, TAU); g.lineWidth = 18; g.strokeStyle = 'rgba(255,255,255,0.5)'; g.stroke(); g.restore(); }
    const rg = g.createRadialGradient(cx - 110, cy - 110, 40, cx, cy, R);
    rg.addColorStop(0, 'rgba(255,255,255,' + (0.9 * p.shade + 0.1) + ')'); rg.addColorStop(1, 'rgba(255,255,255,' + (0.12 * p.shade) + ')');
    g.beginPath(); g.fillStyle = rg; g.arc(cx, cy, R, 0, TAU); g.fill();
    g.beginPath(); g.lineWidth = 4; g.strokeStyle = 'rgba(255,255,255,0.85)'; g.arc(cx, cy, R, 0, TAU); g.stroke();
    // tiny landed rocket
    g.save(); g.translate(cx + R * 0.1, cy - R - 6); drawRocketShape(g, 6, 0.2); g.restore();
    g.fillStyle = '#fff'; g.textAlign = 'center';
    g.font = '700 46px ui-monospace,Menlo,monospace'; g.fillText('P U L S E', 540, 150);
    g.font = '800 92px "SF Pro Display",Arial,sans-serif'; g.fillText(p.name.toUpperCase(), 540, 1030);
    g.font = '400 34px ui-monospace,Menlo,monospace'; g.fillStyle = 'rgba(255,255,255,0.75)';
    g.fillText(p.au.toFixed(2) + ' AU  \u00b7  \u2300 ' + fmt(p.dia) + ' km', 540, 1090);
    g.fillText('X ' + fmt(rocket.x / PPAU() * AU_KM) + '   Y ' + fmt(rocket.y / PPAU() * AU_KM) + ' km', 540, 1140);
    g.fillText(new Date().toISOString().slice(0, 10), 540, 1200);
    const url = c.toDataURL('image/png');
    $('gSnapImg').src = url; $('gDownload').href = url; $('gDownload').setAttribute('download', 'pulse-' + p.id + '.png');
    phase = 'fly'; show('gSnap', true);
  }
  function shareSnap() {
    const p = current; if (!p) return;
    api('/api/game/share', { planet_id: p.id }).then(() => { const r = PULSE().refresh; r && r(); });
    haptic('ok');
    const u = 'https://t.me/share/url?url=' + encodeURIComponent('https://t.me') + '&text=' + encodeURIComponent('I just reached ' + p.name + ' on PULSE \ud83d\ude80');
    try { if (tg && tg.openTelegramLink) tg.openTelegramLink(u); else window.open(u, '_blank'); } catch (_) {}
  }
  function resume() { show('gDiscover', false); show('gSnap', false); phase = 'fly'; }
  function show(id, on) { const el = $(id); if (el) el.hidden = !on; }

  // ---- open / close / launch ---------------------------------------------
  function open() {
    if (!cv) return;
    const st = PULSE().state; reached = new Set((st && st.discovered) || []);
    resize();
    rocket.x = 0; rocket.y = 0; rocket.vx = 0; rocket.vy = 0; rocket.ang = -Math.PI / 2;
    exhaust = []; asteroids = []; shooters = []; debris = [];
    boost = 0; boostReady = 1; shields = 3; invuln = 0; score = 0;
    phase = 'launch'; launchT = 0; landT = 0; deadT = 0; shakeT = 0.3; hintT = 0; current = null;
    show('gDiscover', false); show('gSnap', false);
    const ov = $('gameOverlay'); ov.classList.add('on'); ov.setAttribute('aria-hidden', 'false');
    running = true; last = 0; raf = requestAnimationFrame(loop); updateHud();
  }
  function close() {
    running = false; cancelAnimationFrame(raf);
    const ov = $('gameOverlay'); ov.classList.remove('on'); ov.setAttribute('aria-hidden', 'true');
    show('gDiscover', false); show('gSnap', false);
    const r = PULSE().refresh; r && r();
  }
  function launch() {
    const fab = $('rocketLaunch'); if (fab && fab.classList.contains('go')) return;
    if (fab) fab.classList.add('go'); haptic('hit');
    const app = $('app'); app && app.classList.add('shake');
    setTimeout(() => { app && app.classList.remove('shake'); }, 700);
    setTimeout(() => { open(); if (fab) fab.classList.remove('go'); }, 620);
  }

  addEventListener('resize', () => { if (running) resize(); });
  let wired = false;
  function wire() {
    if (wired) return; wired = true;
    if (cv) bindInput();
    const on = (id, fn, ev) => { const el = $(id); if (el) el.addEventListener(ev || 'click', fn); };
    const fab = $('rocketLaunch');
    if (fab) { let h = false; const fire = e => { if (h) return; h = true; setTimeout(() => (h = false), 500); if (e && e.preventDefault) e.preventDefault(); launch(); }; fab.addEventListener('click', fire); fab.addEventListener('touchend', fire, { passive: false }); }
    on('gExit', close); on('gBoost', fireBoost);
    on('gLand', land); on('gResume', resume); on('gShare', shareSnap); on('gSnapClose', resume);
  }
  if (document.readyState === 'loading') window.addEventListener('DOMContentLoaded', wire); else wire();
  window.PULSE_GAME = { open, close, launch };
})();
