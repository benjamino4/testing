/* ========================================================================
   PULSE - Telegram Mini App
   monochrome deep-space + particle-orb hero + quests + TON wallet
   ===================================================================== */
(() => {
  'use strict';

  // ---- Telegram bootstrap -------------------------------------------------
  const tg = window.Telegram && window.Telegram.WebApp ? window.Telegram.WebApp : null;
  let initData = '';
  if (tg) {
    tg.ready(); tg.expand();
    initData = tg.initData || '';
    applyTheme(tg.colorScheme);
    tg.onEvent('themeChanged', () => applyTheme(tg.colorScheme));
    try { tg.setHeaderColor && tg.setHeaderColor('#000000'); } catch (_) {}
  }
  function applyTheme(scheme) { document.body.classList.toggle('light', scheme === 'light'); }
  function haptic(kind) {
    try {
      if (!tg || !tg.HapticFeedback) return;
      if (kind === 'impact') tg.HapticFeedback.impactOccurred('medium');
      else if (kind === 'success') tg.HapticFeedback.notificationOccurred('success');
      else if (kind === 'light') tg.HapticFeedback.impactOccurred('light');
    } catch (_) {}
  }
  const api = (path, opts = {}) => fetch(path, {
    ...opts,
    headers: { 'Content-Type': 'application/json', 'X-Init-Data': initData, ...(opts.headers || {}) },
  }).then(r => r.json());

  // ---- DOM ----------------------------------------------------------------
  const $ = id => document.getElementById(id);
  const orb = $('orb'), orbLabel = $('orbLabel'), core = document.querySelector('.core');
  const streakNum = $('streakNum'), pointsNum = $('pointsNum'), totalNum = $('totalNum');
  const ringProgress = $('ringProgress'), heat = $('heat'), greet = $('greet');
  const statusEl = $('status'), tasksEl = $('tasks');
  const walletState = $('walletState'), walletAddr = $('walletAddr'), walletBtn = $('walletBtn');
  const walletCard = $('walletCard'), popLayer = $('popLayer');
  const RING_LEN = 691;
  let STATE = null;

  // ---- rolling counters ---------------------------------------------------
  function rollTo(el, target) {
    const start = parseInt(el.textContent, 10) || 0;
    if (start === target) return;
    const dur = 750, t0 = performance.now(), ease = t => 1 - Math.pow(1 - t, 3);
    (function step(now) {
      const p = Math.min(1, (now - t0) / dur);
      el.textContent = Math.round(start + (target - start) * ease(p));
      if (p < 1) requestAnimationFrame(step);
    })(t0);
  }

  // ---- paint state --------------------------------------------------------
  function paint(s) {
    STATE = s;
    window.PULSE.state = s;
    rollTo(streakNum, s.streak || 0);
    rollTo(pointsNum, s.points || 0);
    rollTo(totalNum, s.total || 0);
    const frac = Math.min(1, (s.streak % 7 || (s.streak ? 7 : 0)) / 7);
    ringProgress.style.strokeDashoffset = String(RING_LEN * (1 - frac));
    if (s.name) greet.textContent = 'hello, ' + s.name.toLowerCase();
    if (s.today) { orb.classList.add('done'); orbLabel.innerHTML = 'PULSED<br/>TODAY'; }
    if (s.dev_mode) statusEl.textContent = 'dev mode \u00b7 sign initData in production';
    renderHeat(s.heatmap || []);
    renderTasks(s.tasks || []);
    renderWallet(s.wallet);
  }

  function renderHeat(cells) {
    heat.innerHTML = '';
    cells.forEach((c, i) => {
      const d = document.createElement('div');
      d.className = 'cell' + (c.active ? ' on' : '') + (i === cells.length - 1 ? ' today' : '');
      heat.appendChild(d);
    });
  }

  // ---- tasks --------------------------------------------------------------
  const CHECK = '<svg viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg>';
  const INTERACTIVE = new Set(['manual', 'link', 'wallet']);
  function renderTasks(tasks) {
    tasksEl.innerHTML = '';
    tasks.forEach((t, i) => {
      const el = document.createElement('div');
      const clickable = !t.done && INTERACTIVE.has(t.kind || 'manual');
      el.className = 'task pop-in' + (t.done ? ' done' : '');
      el.setAttribute('data-clickable', clickable ? '1' : '0');
      el.style.animationDelay = (120 + i * 90) + 'ms';
      const idx = String(i + 1).padStart(2, '0');
      el.innerHTML =
        '<div class="task-index">' + idx + '</div>' +
        '<div class="task-check">' + CHECK + '</div>' +
        '<div class="task-main"><div class="task-title">' + esc(t.title) + '</div>' +
        '<div class="task-hint">' + esc(t.hint || '') + '</div></div>' +
        '<div class="task-reward">+' + (t.reward || 0) + '</div>';
      if (clickable) el.addEventListener('click', () => handleTask(t, el));
      else el.style.cursor = 'default';
      tasksEl.appendChild(el);
    });
  }
  function esc(s) { const d = document.createElement('div'); d.textContent = s == null ? '' : s; return d.innerHTML; }

  async function handleTask(t, el) {
    if (el.classList.contains('busy')) return;
    el.classList.add('busy');
    haptic('light');
    const kind = t.kind || 'manual';
    if (kind === 'wallet') { scrollToWallet(); el.classList.remove('busy'); return; }
    if (kind === 'link' && t.url) {
      if (tg && /t\.me\//.test(t.url) && tg.openTelegramLink) tg.openTelegramLink(t.url);
      else if (tg && tg.openLink) tg.openLink(t.url);
      else window.open(t.url, '_blank');
    }
    try { paint(await api('/api/tasks/complete', { method: 'POST', body: JSON.stringify({ initData, task_id: t.id }) })); haptic('success'); }
    catch (_) {} finally { el.classList.remove('busy'); }
  }

  // ---- wallet (TON) -------------------------------------------------------
  function shortAddr(a) { return a && a.length > 12 ? a.slice(0, 6) + '\u2026' + a.slice(-4) : a; }
  function renderWallet(addr) {
    if (addr) {
      walletState.textContent = 'Connected';
      walletAddr.textContent = shortAddr(addr);
      walletBtn.textContent = 'Disconnect';
      walletCard.classList.add('connected');
    } else {
      walletState.textContent = 'Not connected';
      walletAddr.textContent = '\u2014';
      walletBtn.textContent = 'Connect TON';
      walletCard.classList.remove('connected');
    }
  }
  walletBtn.addEventListener('click', async () => {
    if (walletBtn.classList.contains('busy')) return;
    walletBtn.classList.add('busy');
    haptic('impact');
    try {
      if (STATE && STATE.wallet) {
        paint(await api('/api/wallet', { method: 'POST', body: JSON.stringify({ initData, address: '' }) }));
      } else {
        walletBtn.textContent = 'Connecting\u2026';
        // Demo connect: generate a TON-style address. Swap for real TON Connect
        // (see README) to open the user's actual wallet.
        await new Promise(r => setTimeout(r, 900));
        const addr = 'UQ' + Array.from({ length: 46 }, () => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[Math.floor(Math.random() * 32)]).join('');
        paint(await api('/api/wallet', { method: 'POST', body: JSON.stringify({ initData, address: addr }) }));
        haptic('success');
      }
    } catch (_) {} finally { walletBtn.classList.remove('busy'); }
  });
  function scrollToWallet() { $('walletScreen').scrollIntoView({ behavior: 'smooth' }); }

  // ---- pulse (check-in) ---------------------------------------------------
  let busy = false;
  async function pulse() {
    if (busy) return; busy = true;
    const prev = STATE ? (STATE.points || 0) : 0;
    haptic('impact');
    spawnShock(); orbField.burst();
    sparkBurst(); screenShake();
    try {
      const s = await api('/api/checkin', { method: 'POST', body: JSON.stringify({ initData }) });
      const delta = Math.max(0, (s.points || 0) - prev);
      if (delta > 0) floatPoints(delta);
      paint(s); haptic('success');
    }
    catch (_) { statusEl.textContent = 'connection lost \u00b7 try again'; }
    finally { setTimeout(() => (busy = false), 400); }
  }
  function floatPoints(n) {
    if (!popLayer) return;
    const s = document.createElement('span');
    s.className = 'float-pt'; s.textContent = '+' + n;
    s.style.left = (44 + Math.random() * 12) + '%';
    popLayer.appendChild(s); setTimeout(() => s.remove(), 1500);
  }
  orb.addEventListener('click', pulse);
  // screen shake + spark burst on pulse
  function screenShake() {
    const app = $('app'); if (!app) return;
    app.classList.remove('shake'); void app.offsetWidth; app.classList.add('shake');
    setTimeout(() => app.classList.remove('shake'), 460);
  }
  function sparkBurst() {
    if (!core) return;
    const rect = core.getBoundingClientRect();
    const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
    const n = 16;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * 6.2832 + Math.random() * 0.4;
      const dist = 60 + Math.random() * 90;
      const s = document.createElement('span');
      s.className = 'spark';
      s.style.left = cx + 'px'; s.style.top = cy + 'px';
      s.style.setProperty('--dx', (Math.cos(a) * dist) + 'px');
      s.style.setProperty('--dy', (Math.sin(a) * dist) + 'px');
      s.style.animation = 'sparkfly ' + (0.5 + Math.random() * 0.4) + 's var(--ease) forwards';
      document.body.appendChild(s);
      setTimeout(() => s.remove(), 1000);
    }
  }
  function spawnShock() {
    for (let i = 0; i < 3; i++) {
      const s = document.createElement('span');
      s.className = 'shock'; s.style.animationDelay = (i * 130) + 'ms';
      core.appendChild(s); setTimeout(() => s.remove(), 1500 + i * 130);
    }
  }

  // ---- reveal on scroll ---------------------------------------------------
  const revealObserver = new IntersectionObserver(es => {
    es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); revealObserver.unobserve(e.target); } });
  }, { threshold: 0.15 });
  document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));
  const cue = $('scrollCue');
  if (cue) cue.addEventListener('click', () => $('tasksScreen').scrollIntoView({ behavior: 'smooth' }));

  // ---- particle-orb hero (monochrome rotating constellation) --------------
  const orbField = (() => {
    const cv = $('orbCanvas'); const ctx = cv.getContext('2d');
    let W, H, cx, cy, R, dpr = 1;
    let rot = 0, energy = 0, last = 0;
    const N = innerWidth < 640 ? 60 : 90;
    const pts = [];
    for (let i = 0; i < N; i++) {
      const y = 1 - (i / (N - 1)) * 2;          // -1..1, even latitude
      const rad = Math.sqrt(Math.max(0, 1 - y * y));
      pts.push({ y, rad, theta: i * 2.399963, tw: Math.random() * 6.28, sp: 0.4 + Math.random() * 0.9 });
    }
    function resize() {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      const b = cv.getBoundingClientRect();
      W = cv.width = b.width * dpr; H = cv.height = b.height * dpr;
      cx = W / 2; cy = H / 2; R = Math.min(W, H) * 0.34;
    }
    new ResizeObserver(resize).observe(cv); resize();
    function burst() { energy = Math.min(1.5, energy + 1); }
    let px = 0, py = 0;
    cv.addEventListener('pointermove', e => {
      const b = cv.getBoundingClientRect();
      px = (e.clientX - b.left) / b.width - 0.5; py = (e.clientY - b.top) / b.height - 0.5;
    });
    const proj = new Array(N);
    function frame(now) {
      const dt = last ? Math.min(0.05, (now - last) / 1000) : 0.016; last = now;
      rot += dt * (0.22 + px * 0.7); energy *= 0.95;
      const tilt = py * 0.5;
      const ct2 = Math.cos(tilt), st2 = Math.sin(tilt);
      const light = document.body.classList.contains('light');
      const base = light ? '12,14,24' : '255,255,255';
      const exp = 1 + energy * 0.4;
      ctx.clearRect(0, 0, W, H);
      for (let i = 0; i < N; i++) {
        const p = pts[i];
        const ct = Math.cos(p.theta + rot), st = Math.sin(p.theta + rot);
        const x = p.rad * ct, y0 = p.y, z0 = p.rad * st;
        const y = y0 * ct2 - z0 * st2, z = y0 * st2 + z0 * ct2;
        const persp = 0.62 / (1 - z * 0.34);
        proj[i] = { sx: cx + x * R * exp * persp, sy: cy + y * R * exp * persp, d: (z + 1) / 2, tw: p.tw, sp: p.sp };
      }
      // links between near particles
      ctx.lineWidth = dpr * 0.6;
      const maxD = R * 0.52, maxD2 = maxD * maxD;
      for (let i = 0; i < N; i++) {
        const a = proj[i];
        for (let j = i + 1; j < N; j++) {
          const b = proj[j], dx = a.sx - b.sx, dy = a.sy - b.sy, d2 = dx * dx + dy * dy;
          if (d2 < maxD2) {
            const al = (1 - Math.sqrt(d2) / maxD) * 0.16 * ((a.d + b.d) / 2) + energy * 0.05;
            ctx.strokeStyle = `rgba(${base},${al})`;
            ctx.beginPath(); ctx.moveTo(a.sx, a.sy); ctx.lineTo(b.sx, b.sy); ctx.stroke();
          }
        }
      }
      // particles
      for (let i = 0; i < N; i++) {
        const p = proj[i];
        const tw = 0.6 + 0.4 * Math.sin(now * 0.001 * p.sp + p.tw);
        const r = (0.6 + p.d * 1.9) * dpr * (1 + energy * 0.4);
        const al = Math.min(1, (0.22 + p.d * 0.62) * tw + energy * 0.25);
        ctx.beginPath(); ctx.fillStyle = `rgba(${base},${al})`;
        ctx.arc(p.sx, p.sy, r, 0, 6.2832); ctx.fill();
      }
      // soft central glow
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 1.25);
      g.addColorStop(0, `rgba(${base},${(light ? 0.05 : 0.09) + energy * 0.16})`);
      g.addColorStop(1, `rgba(${base},0)`);
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, R * 1.25, 0, 6.2832); ctx.fill();
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
    return { burst };
  })();

  // ---- deep-space: drifting monochrome particles + shooting stars --------
  (() => {
    const cv = $('space'); const ctx = cv.getContext('2d');
    let W, H, dpr = 1; const layers = []; const shooting = [];
    const px = { x: 0, y: 0 };
    function rand(a, b) { return a + Math.random() * (b - a); }
    function resize() {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = cv.width = innerWidth * dpr; H = cv.height = innerHeight * dpr;
      cv.style.width = innerWidth + 'px'; cv.style.height = innerHeight + 'px';
      build();
    }
    function build() {
      layers.length = 0;
      const mobile = innerWidth < 640;
      const div = mobile ? 1.6 : 1;
      const depths = [
        { s: 0.6, sp: 0.004, tw: 0.6, n: Math.round(W * H / (15000 * dpr * div)) },
        { s: 1.0, sp: 0.011, tw: 1.0, n: Math.round(W * H / (30000 * dpr * div)) },
        { s: 1.7, sp: 0.022, tw: 1.4, n: Math.round(W * H / (72000 * dpr * div)) },
      ];
      depths.forEach(d => {
        const stars = [];
        for (let i = 0; i < d.n; i++) stars.push({ x: Math.random() * W, y: Math.random() * H, r: (0.3 + Math.random() * d.s) * dpr, ph: Math.random() * 6.28 });
        layers.push({ ...d, stars });
      });
    }
    resize(); addEventListener('resize', resize);
    addEventListener('pointermove', e => { px.x = (e.clientX / innerWidth - 0.5); px.y = (e.clientY / innerHeight - 0.5); });
    function maybeShoot() {
      if (Math.random() < 0.005 && shooting.length < 2)
        shooting.push({ x: rand(-0.1, 0.4) * W, y: rand(0, 0.5) * H, vx: rand(7, 12) * dpr, vy: rand(2, 4) * dpr, life: 1 });
    }
    let t = 0;
    function frame() {
      t += 0.016;
      const light = document.body.classList.contains('light');
      const base = light ? '10,12,24' : '255,255,255';
      ctx.clearRect(0, 0, W, H);
      layers.forEach((L, li) => {
        const ox = px.x * (li + 1) * 16 * dpr, oy = px.y * (li + 1) * 16 * dpr;
        for (const s of L.stars) {
          s.y += L.sp * dpr; if (s.y > H) { s.y = 0; s.x = Math.random() * W; }
          const tw = 0.55 + 0.45 * Math.sin(t * L.tw + s.ph);
          ctx.beginPath();
          ctx.fillStyle = `rgba(${base},${(light ? 0.45 : 0.85) * tw})`;
          ctx.arc(s.x + ox, s.y + oy, s.r, 0, 6.2832); ctx.fill();
        }
      });
      maybeShoot();
      for (let i = shooting.length - 1; i >= 0; i--) {
        const sh = shooting[i]; sh.x += sh.vx; sh.y += sh.vy; sh.life -= 0.012;
        if (sh.life <= 0 || sh.x > W + 80 * dpr) { shooting.splice(i, 1); continue; }
        const tx = sh.x - sh.vx * 9, ty = sh.y - sh.vy * 9;
        const g = ctx.createLinearGradient(tx, ty, sh.x, sh.y);
        g.addColorStop(0, `rgba(${base},0)`);
        g.addColorStop(1, `rgba(${base},${0.9 * sh.life})`);
        ctx.strokeStyle = g; ctx.lineWidth = 1.6 * dpr; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(sh.x, sh.y); ctx.stroke();
      }
      requestAnimationFrame(frame);
    }
    frame();
  })();

  // ---- intro: particles converge as the logo draws in --------------------
  (() => {
    const cv = $('introCanvas'); if (!cv) return;
    const ctx = cv.getContext('2d');
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const W = cv.width = innerWidth * dpr, H = cv.height = innerHeight * dpr;
    cv.style.width = innerWidth + 'px'; cv.style.height = innerHeight + 'px';
    const cx = W / 2, cy = H / 2;
    function rand(a, b) { return a + Math.random() * (b - a); }
    const N = innerWidth < 640 ? 90 : 150;
    const ps = [];
    for (let i = 0; i < N; i++) {
      const a = Math.random() * 6.28, far = Math.max(W, H) * (0.4 + Math.random() * 0.5), near = rand(12, 95) * dpr;
      ps.push({ x: cx + Math.cos(a) * far, y: cy + Math.sin(a) * far, tx: cx + Math.cos(a) * near, ty: cy + Math.sin(a) * near, r: rand(0.6, 2) * dpr, delay: Math.random() * 0.45 });
    }
    const intro = $('intro');
    const t0 = performance.now();
    function frame(now) {
      const light = document.body.classList.contains('light');
      const base = light ? '10,12,24' : '255,255,255';
      const p = Math.min(1, (now - t0) / 2200), ease = 1 - Math.pow(1 - p, 3);
      ctx.clearRect(0, 0, W, H);
      for (const q of ps) {
        const local = Math.min(1, Math.max(0, (ease - q.delay) / (1 - q.delay)));
        const x = q.x + (q.tx - q.x) * local, y = q.y + (q.ty - q.y) * local;
        ctx.beginPath(); ctx.fillStyle = `rgba(${base},${0.12 + local * 0.6})`;
        ctx.arc(x, y, q.r, 0, 6.2832); ctx.fill();
      }
      if (!(intro && intro.classList.contains('gone'))) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  })();

  // ---- liquid bubbles (quests + wallet screens) --------------------------
  function initBubbles(id) {
    const cv = document.getElementById(id); if (!cv) return;
    const ctx = cv.getContext('2d'); let W, H, dpr = 1; let bubbles = [];
    function rand(a, b) { return a + Math.random() * (b - a); }
    function mk(spread) {
      const r = rand(4, 22) * dpr;
      return { x: rand(0, W || 300), y: spread ? rand(0, H || 600) : (H || 600) + r + rand(0, (H || 600) * 0.3),
        r, vy: rand(6, 20) * dpr / 60, drift: rand(-7, 7) * dpr / 60, ph: Math.random() * 6.28,
        wob: rand(0.4, 1.1), fill: Math.random() < 0.5 };
    }
    function resize() {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      const b = cv.getBoundingClientRect();
      W = cv.width = Math.max(1, b.width) * dpr; H = cv.height = Math.max(1, b.height) * dpr;
      const n = Math.max(6, Math.round(W * H / (95000 * dpr)));
      bubbles = []; for (let i = 0; i < n; i++) bubbles.push(mk(true));
    }
    new ResizeObserver(resize).observe(cv); resize();
    let t = 0;
    function frame() {
      t += 0.016;
      const light = document.body.classList.contains('light');
      const base = light ? '0,0,0' : '255,255,255';
      ctx.clearRect(0, 0, W, H);
      for (const b of bubbles) {
        b.y -= b.vy; b.x += b.drift + Math.sin(t * b.wob + b.ph) * 0.35 * dpr;
        if (b.y + b.r < 0) Object.assign(b, mk(false));
        ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, 6.2832);
        if (b.fill) { ctx.fillStyle = `rgba(${base},0.05)`; ctx.fill(); }
        ctx.strokeStyle = `rgba(${base},0.14)`; ctx.lineWidth = dpr; ctx.stroke();
        ctx.beginPath(); ctx.arc(b.x - b.r * 0.3, b.y - b.r * 0.3, b.r * 0.18, 0, 6.2832);
        ctx.fillStyle = `rgba(${base},0.24)`; ctx.fill();
      }
      requestAnimationFrame(frame);
    }
    frame();
  }
  initBubbles('bubblesTasks'); initBubbles('bubblesWallet'); initBubbles('bubblesHero');

  // ---- hero micro-interactions -------------------------------------------
  const ringEl = document.querySelector('.ring');
  addEventListener('pointermove', e => {
    const dx = (e.clientX / innerWidth - 0.5), dy = (e.clientY / innerHeight - 0.5);
    if (ringEl) ringEl.style.transform = 'rotate(-90deg) translate(' + (dy * 10) + 'px,' + (-dx * 10) + 'px)';
  }, { passive: true });
  document.querySelectorAll('.stat').forEach(st => {
    st.style.cursor = 'pointer';
    st.addEventListener('click', () => { st.classList.remove('ping'); void st.offsetWidth; st.classList.add('ping'); haptic('light'); });
  });

  // ---- expose bridge for the space-explorer game -------------------------
  window.PULSE = {
    get initData() { return initData; },
    state: null,
    refresh: () => api('/api/state').then(paint).catch(() => {}),
  };

  // ---- intro + initial load ----------------------------------------------
  const intro = $('intro');
  setTimeout(() => { if (intro) intro.classList.add('gone'); haptic('light'); }, 2900);
  api('/api/state').then(paint).catch(() => {
    statusEl.textContent = 'offline \u00b7 tap to pulse when connected';
  });
})();
