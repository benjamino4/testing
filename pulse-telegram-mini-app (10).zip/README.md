# PULSE — Telegram Mini App

A monochrome (black & white) Telegram Mini App set in deep space. On first load
a pulse blooms out of the void (cinematic intro), then you land on a living
starfield — parallax star layers, twinkling, drifting nebula, and the occasional
shooting star. The hero is a **fluid organic orb** (smooth summed-sine blobs, no
jitter) that breathes and swells when you tap it. Scroll down for two more
sections: **Daily Quests** and a **TON Wallet** connect card.

Features
- Deep-space background: 3 parallax star layers, twinkle, nebula drift, shooting stars.
- Fluid pulsing orb rendered on canvas; shockwave ripples + haptics on every tap.
- Cinematic load animation (expanding pulse + wordmark reveal).
- Daily streak, energy (points), total pulses, 7-day heatmap, self-drawing ring.
- Daily Quests section with animated check-offs and rewards.
- TON Wallet section (connect / disconnect) with reward on connect.
- Telegram theme sync (dark/light), haptics, fullscreen expand, signed initData.


```
pulse/
  backend/
    main.py          FastAPI app: initData validation + streak API + serves the UI
    requirements.txt
  frontend/
    index.html
    styles.css       monochrome theme, orb, ring, heatmap, grain overlay
    app.js           Telegram SDK + canvas particle engine + API calls
```

## Run locally (dev mode)

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000 in a browser. With no `BOT_TOKEN` set the server
runs in **DEV mode** — it trusts a demo user so you can click around without
Telegram. The UI shows a "dev mode" note so you never ship it by accident.

## Go live with a real bot

1. Create a bot with [@BotFather](https://t.me/BotFather) and copy its token.
2. Set the token and start the server (behind HTTPS — Telegram requires it):
   ```bash
   export BOT_TOKEN="123456:ABC..."
   uvicorn main:app --host 127.0.0.1 --port 8000
   ```
   Put a reverse proxy (nginx / Caddy) with a valid TLS cert in front, or
   deploy to any host that gives you HTTPS.
3. In BotFather run `/newapp` (or `/setmenubutton`) and point the Mini App /
   menu button URL at your public HTTPS address.
4. Open the bot in Telegram → launch the Mini App. It will now validate the
   signed `initData`, so every streak is tied to the real Telegram user id.

## Security notes

- **initData is verified** with HMAC-SHA256 against your bot token, plus a 24h
  freshness check. Requests with a bad or missing signature get `401`.
- Never expose the server publicly **without** `BOT_TOKEN` set — dev mode is
  for local testing only.
- The server binds to `127.0.0.1`; terminate TLS in your own proxy.
- Data is stored in a local `pulse.db` (SQLite). Point `PULSE_DB` elsewhere or
  swap in Postgres for production scale.

## Customize

- Colors / theme: CSS variables at the top of `styles.css` (`--bg`, `--fg`, ...).
- Star density / speed: the `depths` array in the starfield module in `app.js`.
- Orb fluidity: the `blob()` sine weights and `energy` decay in the orb module.
- Quests: the `TASKS` catalogue in `backend/main.py` (title, hint, reward, kind).

## Real TON wallet (production)

The wallet button ships as a **demo** that generates a TON-style address so you
can see the full flow offline. To connect real wallets, drop in TON Connect:

1. Host a `tonconnect-manifest.json` (name, url, icon) at your public URL.
2. Add the TON Connect UI SDK, e.g. in `index.html`:
   ```html
   <script src="https://unpkg.com/@tonconnect/ui@2/dist/tonconnect-ui.min.js"></script>
   ```
3. Replace the demo branch in the wallet button handler (`app.js`) with:
   ```js
   const ui = new TON_CONNECT_UI.TonConnectUI({ manifestUrl: '<your>/tonconnect-manifest.json' });
   const wallet = await ui.connectWallet();
   // then POST wallet.account.address to /api/wallet as today
   ```
The backend already stores whatever address you POST to `/api/wallet`, so no
server change is needed.

